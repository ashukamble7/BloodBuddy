package com.example.bloodbuddy.service;

import com.example.bloodbuddy.model.User;
import com.example.bloodbuddy.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> searchDonors(String bloodGroup, String city) {
        return userRepository.findByBloodGroupAndCityAndAvailableTrue(bloodGroup, city);
    }
}
