package com.example.bloodbuddy.controller;

import com.example.bloodbuddy.model.User;
import com.example.bloodbuddy.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin("*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return authService.registerUser(user);
    }

    @PostMapping("/login")
    public User login(@RequestBody User user) {
        return authService.loginUser(user.getEmail(), user.getPassword());
    }
}
