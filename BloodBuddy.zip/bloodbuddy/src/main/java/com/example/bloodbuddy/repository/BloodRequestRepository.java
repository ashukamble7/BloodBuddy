package com.example.bloodbuddy.repository;

import com.example.bloodbuddy.model.BloodRequest;
import com.example.bloodbuddy.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {
    List<BloodRequest> findByRequester(User requester);
}
