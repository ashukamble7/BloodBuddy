package com.example.bloodbuddy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodbuddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloodbuddyApplication.class, args);
	}

}
