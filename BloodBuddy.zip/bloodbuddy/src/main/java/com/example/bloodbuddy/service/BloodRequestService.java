package com.example.bloodbuddy.service;

import com.example.bloodbuddy.model.BloodRequest;
import com.example.bloodbuddy.model.User;
import com.example.bloodbuddy.repository.BloodRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BloodRequestService {

    @Autowired
    private BloodRequestRepository bloodRequestRepository;

    public BloodRequest createRequest(BloodRequest request) {
        return bloodRequestRepository.save(request);
    }

    public List<BloodRequest> getRequestsByUser(User user) {
        return bloodRequestRepository.findByRequester(user);
    }
}
