package com.example.bloodbuddy.controller;

import com.example.bloodbuddy.model.User;
import com.example.bloodbuddy.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/donors")
@CrossOrigin("*")
public class DonorController {

    @Autowired
    private UserService userService;

    @GetMapping("/search")
    public List<User> search(@RequestParam String bloodGroup, @RequestParam String city) {
        return userService.searchDonors(bloodGroup, city);
    }
}
