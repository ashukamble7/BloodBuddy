package com.example.bloodbuddy.controller;

import com.example.bloodbuddy.model.BloodRequest;
import com.example.bloodbuddy.model.User;
import com.example.bloodbuddy.repository.UserRepository;
import com.example.bloodbuddy.service.BloodRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
@CrossOrigin("*")
public class BloodRequestController {

    @Autowired
    private BloodRequestService requestService;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/create")
    public BloodRequest createRequest(@RequestBody BloodRequest request) {
        if (request.getRequester() != null && request.getRequester().getId() != null) {
            User user = userRepository.findById(request.getRequester().getId()).orElseThrow();
            request.setRequester(user);
        }
        return requestService.createRequest(request);
    }

    @GetMapping("/by-user/{userId}")
    public List<BloodRequest> getByUser(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElseThrow();
        return requestService.getRequestsByUser(user);
    }
}
